package com.example.artspace

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.artspace.ui.theme.ArtSpaceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ArtSpaceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ArtSpaceLayout()
                }
            }
        }
    }
}

@Composable
fun ArtSpaceLayout() {
    // state: which artwork is shown (1, 2 or 3), kept with remember
    var currentArtwork by remember { mutableStateOf(1) }

    val imageResource = when (currentArtwork) {
        1 -> R.drawable.artwork_1
        2 -> R.drawable.artwork_2
        else -> R.drawable.artwork_3
    }
    val titleResource = when (currentArtwork) {
        1 -> R.string.title_1
        2 -> R.string.title_2
        else -> R.string.title_3
    }
    val artistResource = when (currentArtwork) {
        1 -> R.string.artist_1
        2 -> R.string.artist_2
        else -> R.string.artist_3
    }
    val yearResource = when (currentArtwork) {
        1 -> R.string.year_1
        2 -> R.string.year_2
        else -> R.string.year_3
    }

    Column(
        modifier = Modifier
            .statusBarsPadding()
            .padding(horizontal = 40.dp)
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ArtworkWall(
            imageResource = imageResource,
            description = stringResource(titleResource),
            modifier = Modifier.padding(top = 40.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        ArtworkDescriptor(
            title = stringResource(titleResource),
            artist = stringResource(artistResource),
            year = stringResource(yearResource)
        )
        Spacer(modifier = Modifier.height(24.dp))
        DisplayController(
            onPrevious = {
                currentArtwork = if (currentArtwork == 1) 3 else currentArtwork - 1
            },
            onNext = {
                currentArtwork = if (currentArtwork == 3) 1 else currentArtwork + 1
            },
            modifier = Modifier.padding(bottom = 24.dp)
        )
    }
}

@Composable
fun ArtworkWall(
    imageResource: Int,
    description: String,
    modifier: Modifier = Modifier
) {
    // frame with a shadow around the picture
    Surface(shadowElevation = 8.dp, modifier = modifier.fillMaxWidth()) {
        Image(
            painter = painterResource(imageResource),
            contentDescription = description,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
                .height(340.dp)
        )
    }
}

@Composable
fun ArtworkDescriptor(
    title: String,
    artist: String,
    year: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFFECEBF4))
            .padding(16.dp)
    ) {
        Text(text = title, fontSize = 28.sp)
        Text(
            text = stringResource(R.string.artist_year, artist, year),
            fontSize = 16.sp
        )
    }
}

@Composable
fun DisplayController(
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Button(onClick = onPrevious, modifier = Modifier.width(130.dp)) {
            Text(text = stringResource(R.string.previous))
        }
        Button(onClick = onNext, modifier = Modifier.width(130.dp)) {
            Text(text = stringResource(R.string.next))
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ArtSpaceLayoutPreview() {
    ArtSpaceTheme {
        ArtSpaceLayout()
    }
}